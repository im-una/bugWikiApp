package com.example.companymaps.data

data class Library(
    val data: List<Data>,
    val schema: Schema
)