package com.example.companymaps.data

data class Field(
    val name: String,
    val type: String
)